$[ /home/xc93/csl-demo/proof-transfer/module-symbol.mm $]

$( string literal "true" $)
$c "true" "true"-symbol $.
string-literal-0-is-symbol $a #Symbol "true"-symbol $.
string-literal-0-is-pattern $a #Pattern "true" $.
string-literal-0-is-sugar $a #Notation "true" "true"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortBool{}, \equals{SortBool{}, x0}(x1:SortBool{}, \dv{SortBool{}}("true"))) $)
domain-value-0-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortBool kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortBool kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) ) $.

$( string literal "0" $)
$c "0" "0"-symbol $.
string-literal-1-is-symbol $a #Symbol "0"-symbol $.
string-literal-1-is-pattern $a #Pattern "0" $.
string-literal-1-is-sugar $a #Notation "0" "0"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("0"))) $)
domain-value-1-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "0" ) ) ) ) ) $.

$( string literal "r+" $)
$c "r%2B" "r%2B"-symbol $.
string-literal-2-is-symbol $a #Symbol "r%2B"-symbol $.
string-literal-2-is-pattern $a #Pattern "r%2B" $.
string-literal-2-is-sugar $a #Notation "r%2B" "r%2B"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}("r+"))) $)
domain-value-2-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "r%2B" ) ) ) ) ) $.

$( string literal "2" $)
$c "2" "2"-symbol $.
string-literal-3-is-symbol $a #Symbol "2"-symbol $.
string-literal-3-is-pattern $a #Pattern "2" $.
string-literal-3-is-sugar $a #Notation "2" "2"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("2"))) $)
domain-value-3-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "2" ) ) ) ) ) $.

$( string literal "1" $)
$c "1" "1"-symbol $.
string-literal-4-is-symbol $a #Symbol "1"-symbol $.
string-literal-4-is-pattern $a #Pattern "1" $.
string-literal-4-is-sugar $a #Notation "1" "1"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("1"))) $)
domain-value-4-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ) $.

$( string literal "false" $)
$c "false" "false"-symbol $.
string-literal-5-is-symbol $a #Symbol "false"-symbol $.
string-literal-5-is-pattern $a #Pattern "false" $.
string-literal-5-is-sugar $a #Notation "false" "false"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortBool{}, \equals{SortBool{}, x0}(x1:SortBool{}, \dv{SortBool{}}("false"))) $)
domain-value-5-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortBool kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortBool kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortBool "false" ) ) ) ) ) $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}("false"))) $)
domain-value-6-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "false" ) ) ) ) ) $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}("true"))) $)
domain-value-7-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "true" ) ) ) ) ) $.

$( string literal "" $)
$c "" ""-symbol $.
string-literal-6-is-symbol $a #Symbol ""-symbol $.
string-literal-6-is-pattern $a #Pattern "" $.
string-literal-6-is-sugar $a #Notation "" ""-symbol $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}(""))) $)
domain-value-8-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "" ) ) ) ) ) $.

$( string literal "-1" $)
$c "-1" "-1"-symbol $.
string-literal-7-is-symbol $a #Symbol "-1"-symbol $.
string-literal-7-is-pattern $a #Pattern "-1" $.
string-literal-7-is-sugar $a #Notation "-1" "-1"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-1"))) $)
domain-value-9-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) ) $.

$( string literal "_" $)
$c "_" "_"-symbol $.
string-literal-8-is-symbol $a #Symbol "_"-symbol $.
string-literal-8-is-pattern $a #Pattern "_" $.
string-literal-8-is-sugar $a #Notation "_" "_"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}("_"))) $)
domain-value-10-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "_" ) ) ) ) ) $.

$( string literal "$PGM" $)
$c "%24PGM" "%24PGM"-symbol $.
string-literal-9-is-symbol $a #Symbol "%24PGM"-symbol $.
string-literal-9-is-pattern $a #Pattern "%24PGM" $.
string-literal-9-is-sugar $a #Notation "%24PGM" "%24PGM"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortKConfigVar{}, \equals{SortKConfigVar{}, x0}(x1:SortKConfigVar{}, \dv{SortKConfigVar{}}("$PGM"))) $)
domain-value-11-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortKConfigVar kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortKConfigVar kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortKConfigVar "%24PGM" ) ) ) ) ) $.

$( string literal "100" $)
$c "100" "100"-symbol $.
string-literal-10-is-symbol $a #Symbol "100"-symbol $.
string-literal-10-is-pattern $a #Pattern "100" $.
string-literal-10-is-sugar $a #Notation "100" "100"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("100"))) $)
domain-value-12-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "100" ) ) ) ) ) $.

$( string literal "balanceTo" $)
$c "balanceTo" "balanceTo"-symbol $.
string-literal-11-is-symbol $a #Symbol "balanceTo"-symbol $.
string-literal-11-is-pattern $a #Pattern "balanceTo" $.
string-literal-11-is-sugar $a #Notation "balanceTo" "balanceTo"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("balanceTo"))) $)
domain-value-13-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "balanceTo" ) ) ) ) ) $.

$( string literal "200" $)
$c "200" "200"-symbol $.
string-literal-12-is-symbol $a #Symbol "200"-symbol $.
string-literal-12-is-pattern $a #Pattern "200" $.
string-literal-12-is-sugar $a #Notation "200" "200"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("200"))) $)
domain-value-14-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "200" ) ) ) ) ) $.

$( string literal "ret" $)
$c "ret" "ret"-symbol $.
string-literal-13-is-symbol $a #Symbol "ret"-symbol $.
string-literal-13-is-pattern $a #Pattern "ret" $.
string-literal-13-is-sugar $a #Notation "ret" "ret"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("ret"))) $)
domain-value-15-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "ret" ) ) ) ) ) $.

$( string literal "amount" $)
$c "amount" "amount"-symbol $.
string-literal-14-is-symbol $a #Symbol "amount"-symbol $.
string-literal-14-is-pattern $a #Pattern "amount" $.
string-literal-14-is-sugar $a #Notation "amount" "amount"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("amount"))) $)
domain-value-16-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "amount" ) ) ) ) ) $.

$( string literal "12345" $)
$c "12345" "12345"-symbol $.
string-literal-15-is-symbol $a #Symbol "12345"-symbol $.
string-literal-15-is-pattern $a #Pattern "12345" $.
string-literal-15-is-sugar $a #Notation "12345" "12345"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("12345"))) $)
domain-value-17-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "12345" ) ) ) ) ) $.

$( string literal "balanceSender" $)
$c "balanceSender" "balanceSender"-symbol $.
string-literal-16-is-symbol $a #Symbol "balanceSender"-symbol $.
string-literal-16-is-pattern $a #Pattern "balanceSender" $.
string-literal-16-is-sugar $a #Notation "balanceSender" "balanceSender"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("balanceSender"))) $)
domain-value-18-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "balanceSender" ) ) ) ) ) $.

$( string literal "addressTo" $)
$c "addressTo" "addressTo"-symbol $.
string-literal-17-is-symbol $a #Symbol "addressTo"-symbol $.
string-literal-17-is-pattern $a #Pattern "addressTo" $.
string-literal-17-is-sugar $a #Notation "addressTo" "addressTo"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("addressTo"))) $)
domain-value-19-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "addressTo" ) ) ) ) ) $.

$( string literal "10" $)
$c "10" "10"-symbol $.
string-literal-18-is-symbol $a #Symbol "10"-symbol $.
string-literal-18-is-pattern $a #Pattern "10" $.
string-literal-18-is-sugar $a #Notation "10" "10"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("10"))) $)
domain-value-20-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "10" ) ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-GT-IntUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds-GT-'Int'Unds' ( \kore-dv \kore-sort-SortInt "10" ) ( \kore-dv \kore-sort-SortInt "100" ) ) ( \kore-dv \kore-sort-SortBool "false" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "90" $)
$c "90" "90"-symbol $.
string-literal-19-is-symbol $a #Symbol "90"-symbol $.
string-literal-19-is-pattern $a #Pattern "90" $.
string-literal-19-is-sugar $a #Notation "90" "90"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("90"))) $)
domain-value-21-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "90" ) ) ) ) ) $.
LblUnds-IntUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "100" ) ( \kore-dv \kore-sort-SortInt "10" ) ) ( \kore-dv \kore-sort-SortInt "90" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "210" $)
$c "210" "210"-symbol $.
string-literal-20-is-symbol $a #Symbol "210"-symbol $.
string-literal-20-is-pattern $a #Pattern "210" $.
string-literal-20-is-sugar $a #Notation "210" "210"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("210"))) $)
domain-value-22-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "210" ) ) ) ) ) $.
LblUndsPlusIntUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "200" ) ( \kore-dv \kore-sort-SortInt "10" ) ) ( \kore-dv \kore-sort-SortInt "210" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblMapColnlookup-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortKItem kore-sort-var-R ( \kore-symbol-LblMap'Coln'lookup ( \kore-symbol-Lbl'Unds'Map'Unds' \kore-symbol-Lbl'Stop'Map ( \kore-symbol-Lbl'UndsPipe'-'-GT-Unds' ( \kore-inj \kore-sort-SortKConfigVar \kore-sort-SortKItem ( \kore-dv \kore-sort-SortKConfigVar "%24PGM" ) ) ( \kore-inj \kore-sort-SortPgm \kore-sort-SortKItem ( \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "addressTo" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "amount" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "balanceSender" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "balanceTo" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "ret" ) \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids ) ) ) ) ) ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "addressTo" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "12345" ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "amount" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "10" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "balanceSender" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "100" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "balanceTo" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "200" ) ) ) ) ( \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block ( \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "amount" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "balanceSender" ) ) ) ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ret" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "0" ) ) ) ) ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "balanceSender" ) ( \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "balanceSender" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "amount" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "balanceTo" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "balanceTo" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "amount" ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ret" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ) ) ) ) ) ) ) ( \kore-inj \kore-sort-SortKConfigVar \kore-sort-SortKItem ( \kore-dv \kore-sort-SortKConfigVar "%24PGM" ) ) ) ( \kore-inj \kore-sort-SortPgm \kore-sort-SortKItem ( \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "addressTo" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "amount" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "balanceSender" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "balanceTo" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "ret" ) \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids ) ) ) ) ) ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "addressTo" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "12345" ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "amount" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "10" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "balanceSender" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "100" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "balanceTo" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "200" ) ) ) ) ( \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block ( \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "amount" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "balanceSender" ) ) ) ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ret" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "0" ) ) ) ) ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "balanceSender" ) ( \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "balanceSender" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "amount" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "balanceTo" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "balanceTo" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "amount" ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ret" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ) ) ) ) ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-2 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-3 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-2 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-4 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-5 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-GT-IntUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds-GT-'Int'Unds' ( \kore-dv \kore-sort-SortInt "10" ) ( \kore-dv \kore-sort-SortInt "100" ) ) ( \kore-dv \kore-sort-SortBool "false" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-6 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-3 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-7 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-4 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-8 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-9 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-10 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-5 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-11 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-12 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "100" ) ( \kore-dv \kore-sort-SortInt "10" ) ) ( \kore-dv \kore-sort-SortInt "90" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-13 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-6 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-14 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-7 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-15 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-16 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-17 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-8 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-18 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-19 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsPlusIntUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "200" ) ( \kore-dv \kore-sort-SortInt "10" ) ) ( \kore-dv \kore-sort-SortInt "210" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-20 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.
